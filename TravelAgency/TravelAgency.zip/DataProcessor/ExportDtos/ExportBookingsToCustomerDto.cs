﻿namespace TravelAgency.DataProcessor.ExportDtos
{
    public class ExportBookingsToCustomerDto
    {
        public string TourPackageName { get; set; } = null!;

        public string Date { get; set; } = null!;
    }
}
